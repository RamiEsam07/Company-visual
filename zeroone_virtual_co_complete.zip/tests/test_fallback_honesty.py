"""
اختبار مقصود بمعزل: يتأكد أن النظام صادق بوضوح عندما لا يتوفر مفتاح
API — كل مخرج يُعلّم real_thinking=False بدل التظاهر بتفكير فعلي.
هذا يحمي من أخطر خلل ممكن: نظام يدّعي ذكاءً غير موجود فعليًا.
"""

import pytest

import core.thinking as thinking_module
from core.office import VirtualOffice
from core.task import TaskStatus


@pytest.fixture(autouse=True)
def no_api_key(monkeypatch):
    monkeypatch.setattr(thinking_module, "_client", None)
    monkeypatch.setattr(thinking_module, "_client_init_error", None)
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    yield


@pytest.mark.asyncio
async def test_every_artifact_declares_non_real_thinking_without_api_key():
    office = VirtualOffice()
    task = await office.submit(
        title="تصميم صفحة هبوط لحملة تسويقية",
        brief="نحتاج صفحة هبوط لمنتج جديد",
    )
    assert task.artifacts, "يجب أن تنتج المهمة مخرجات حتى بدون مفتاح API"
    for role_name, artifact in task.artifacts.items():
        assert artifact.get("real_thinking") is False, (
            f"مخرج {role_name} لم يُعلن بوضوح أنه احتياطي (غير فعلي)"
        )


@pytest.mark.asyncio
async def test_task_still_completes_via_fallback_without_api_key():
    """النظام يجب أن يستمر بالعمل (بالاحتياطي) حتى بدون مفتاح — لا يتجمد."""
    office = VirtualOffice()
    task = await office.submit(title="عنوان", brief="وصف عام")
    assert task.status in (TaskStatus.DONE, TaskStatus.REJECTED)
