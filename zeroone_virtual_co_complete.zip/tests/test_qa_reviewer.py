"""
اختبارات agents/qa_reviewer.py — أخطر جزء منطقي بالنظام:
يجب ألا تدخل مهمة في حلقة رفض/إعادة لا نهائية.
"""

import pytest

from agents.qa_reviewer import QAReviewerAgent, MAX_REVISIONS
from core.task import Role, Task, TaskStatus


@pytest.fixture
def qa():
    return QAReviewerAgent()


@pytest.mark.asyncio
async def test_approves_task_with_artifact(qa):
    task = Task(title="عنوان", brief="")
    task.assign(Role.QA)
    task.artifacts["developer"] = {"summary": "شي", "status": "draft"}
    await qa.handle(task)
    assert task.status == TaskStatus.DONE


@pytest.mark.asyncio
async def test_rejects_task_with_no_artifact(qa):
    task = Task(title="عنوان", brief="")
    task.assign(Role.QA)
    await qa.handle(task)
    assert task.status == TaskStatus.NEEDS_REVIEW
    assert task.revision_count == 1


@pytest.mark.asyncio
async def test_rejected_task_returns_to_last_producing_role(qa):
    task = Task(title="عنوان", brief="")
    task.assign(Role.DEVELOPER)
    task.log(actor="developer", kind="artifact_ready", message="مخرج فاضي تقنيًا")
    # نحاكي حالة فشل: لا artifacts فعليًا رغم وجود سجل "artifact_ready"
    task.assign(Role.QA)
    await qa.handle(task)
    assert task.assigned_to == Role.DEVELOPER


@pytest.mark.asyncio
async def test_stops_after_max_revisions_without_infinite_loop(qa):
    task = Task(title="عنوان", brief="")
    task.assign(Role.QA)

    for _ in range(MAX_REVISIONS):
        await qa.handle(task)
        assert task.status != TaskStatus.REJECTED  # لسا ضمن الحد المسموح
        task.assign(Role.QA)  # نحاكي إرجاعها للمراجعة مرة ثانية بدون إصلاح

    # التجاوز: المحاولة التالية بعد استنفاد الحد يجب أن توقف نهائيًا
    await qa.handle(task)
    assert task.status == TaskStatus.REJECTED
    assert task.revision_count == MAX_REVISIONS + 1


@pytest.mark.asyncio
async def test_revision_count_never_resets_on_repeated_rejection(qa):
    task = Task(title="عنوان", brief="")
    task.assign(Role.QA)
    await qa.handle(task)
    first_count = task.revision_count
    task.assign(Role.QA)
    await qa.handle(task)
    assert task.revision_count == first_count + 1
