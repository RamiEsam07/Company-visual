"""
اختبارات core/thinking.py — أهم شي نتأكد منه: لما ما فيه مفتاح API،
النظام يفشل بوضوح (ThinkingUnavailable) بدل ما يتظاهر بتفكير وهمي.
"""

import pytest

import core.thinking as thinking_module
from core.thinking import ThinkingUnavailable, think


@pytest.fixture(autouse=True)
def reset_client_cache(monkeypatch):
    """كل اختبار يبدأ بحالة عميل نظيفة، بدون أثر من اختبار سابق."""
    monkeypatch.setattr(thinking_module, "_client", None)
    monkeypatch.setattr(thinking_module, "_client_init_error", None)
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    yield


@pytest.mark.asyncio
async def test_raises_clear_error_without_api_key():
    with pytest.raises(ThinkingUnavailable, match="ANTHROPIC_API_KEY"):
        await think(persona="شخصية تجريبية", task_context="سياق تجريبي")


@pytest.mark.asyncio
async def test_does_not_silently_return_fake_text_without_key():
    """تحقق صريح: الفشل يرفع استثناء، لا يرجع نصًا يبدو كأنه رد حقيقي."""
    with pytest.raises(ThinkingUnavailable):
        result = await think(persona="أي", task_context="أي")
        assert False, f"لم يكن يجب أن يرجع نصًا: {result}"
