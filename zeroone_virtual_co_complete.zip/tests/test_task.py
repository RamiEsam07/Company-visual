"""اختبارات core/task.py — سلوك المهمة الأساسي بمعزل عن أي وكيل."""

from core.task import Role, Task, TaskStatus


def test_new_task_starts_queued():
    task = Task(title="عنوان", brief="وصف")
    assert task.status == TaskStatus.QUEUED
    assert task.assigned_to is None
    assert task.revision_count == 0
    assert task.artifacts == {}


def test_task_gets_unique_id():
    t1 = Task(title="أ", brief="ب")
    t2 = Task(title="أ", brief="ب")
    assert t1.id != t2.id


def test_assign_sets_role_and_in_progress():
    task = Task(title="عنوان", brief="وصف")
    task.assign(Role.DEVELOPER)
    assert task.assigned_to == Role.DEVELOPER
    assert task.status == TaskStatus.IN_PROGRESS


def test_hand_off_changes_assignee_and_status():
    task = Task(title="عنوان", brief="وصف")
    task.assign(Role.MANAGER)
    task.hand_off(Role.DESIGNER, note="تسليم للتصميم")
    assert task.assigned_to == Role.DESIGNER
    assert task.status == TaskStatus.HANDED_OFF


def test_hand_off_logs_event_with_correct_actor():
    task = Task(title="عنوان", brief="وصف")
    task.assign(Role.MANAGER)
    task.hand_off(Role.DESIGNER)
    last = task.history[-1]
    assert last.actor == "manager"  # المرسل هو من كان مسؤولاً قبل التسليم
    assert last.kind == "handoff"
    assert last.payload["to"] == "designer"


def test_log_appends_to_history_in_order():
    task = Task(title="عنوان", brief="وصف")
    task.log(actor="system", kind="created", message="أول حدث")
    task.log(actor="manager", kind="started", message="ثاني حدث")
    assert [e.kind for e in task.history] == ["created", "started"]


def test_to_dict_contains_expected_keys():
    task = Task(title="عنوان", brief="وصف")
    task.assign(Role.MANAGER)
    d = task.to_dict()
    assert d["id"] == task.id
    assert d["status"] == "in_progress"
    assert d["assigned_to"] == "manager"
    assert isinstance(d["history"], list)
    assert isinstance(d["artifacts"], dict)
