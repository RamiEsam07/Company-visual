"""اختبارات agents/designer.py — يسلّم للمطور فقط إذا العمل يحتاج تنفيذ تقني."""

import pytest

from agents.designer import DesignerAgent
from core.task import Role, Task


@pytest.fixture
def designer():
    return DesignerAgent()


@pytest.mark.asyncio
async def test_pure_design_work_goes_straight_to_qa(designer):
    task = Task(title="تصميم شعار", brief="شعار وألوان فقط")
    task.assign(Role.DESIGNER)
    await designer.handle(task)
    assert task.assigned_to == Role.QA


@pytest.mark.asyncio
async def test_website_design_goes_to_developer(designer):
    task = Task(title="تصميم موقع جديد", brief="واجهة تفاعلية كاملة")
    task.assign(Role.DESIGNER)
    await designer.handle(task)
    assert task.assigned_to == Role.DEVELOPER


@pytest.mark.asyncio
async def test_designer_produces_artifact(designer):
    task = Task(title="تصميم شعار", brief="")
    task.assign(Role.DESIGNER)
    await designer.handle(task)
    assert "designer" in task.artifacts
