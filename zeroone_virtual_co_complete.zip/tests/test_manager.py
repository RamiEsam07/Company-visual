"""اختبارات agents/manager.py — هل التوجيه يختار الدور الصحيح."""

import pytest

from agents.manager import ManagerAgent
from core.task import Role, Task, TaskStatus


@pytest.fixture
def manager():
    return ManagerAgent()


def test_routes_design_keywords_to_designer(manager):
    task = Task(title="تصميم شعار جديد", brief="نحتاج هوية بصرية")
    assert manager.route(task) == Role.DESIGNER


def test_routes_marketing_keywords_to_marketer(manager):
    task = Task(title="حملة تسويقية", brief="محتوى للسوشال ميديا")
    assert manager.route(task) == Role.MARKETER


def test_routes_dev_keywords_to_developer(manager):
    task = Task(title="إصلاح باغ بالموقع", brief="فيه خطأ بالكود")
    assert manager.route(task) == Role.DEVELOPER


def test_unclear_request_defaults_to_developer(manager):
    task = Task(title="شي غامض جدًا", brief="ما أدري بالضبط")
    assert manager.route(task) == Role.DEVELOPER


@pytest.mark.asyncio
async def test_handle_assigns_and_hands_off(manager):
    task = Task(title="تصميم واجهة", brief="")
    await manager.handle(task)
    assert task.assigned_to == Role.DESIGNER
    assert task.status == TaskStatus.HANDED_OFF


@pytest.mark.asyncio
async def test_handle_logs_routing_decision(manager):
    task = Task(title="تصميم واجهة", brief="")
    await manager.handle(task)
    kinds = [e.kind for e in task.history]
    assert "started" in kinds
    assert "routing_decision" in kinds
