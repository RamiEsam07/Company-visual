"""
اختبارات core/office.py — السيناريو الكامل end-to-end، وسقف الأمان
الذي يمنع أي حلقة تنقل لا نهائية بين الوكلاء.
"""

import pytest

from core.office import VirtualOffice
from core.task import TaskStatus


@pytest.fixture
def office():
    return VirtualOffice()


@pytest.mark.asyncio
async def test_design_request_flows_through_designer_developer_qa(office):
    task = await office.submit(
        title="تصميم صفحة هبوط لحملة تسويقية",
        brief="نحتاج صفحة هبوط لمنتج جديد",
    )
    actors = [e.actor for e in task.history]
    assert "designer" in actors
    assert "developer" in actors
    assert "qa_reviewer" in actors
    assert task.status == TaskStatus.DONE


@pytest.mark.asyncio
async def test_pure_marketing_request_skips_developer(office):
    task = await office.submit(
        title="حملة إعلانية",
        brief="محتوى تسويقي للسوشال ميديا",
    )
    actors = [e.actor for e in task.history]
    assert "marketer" in actors
    assert "developer" not in actors
    assert task.status == TaskStatus.DONE


@pytest.mark.asyncio
async def test_submitted_task_is_retrievable(office):
    task = await office.submit(title="عنوان", brief="وصف")
    fetched = office.get(task.id)
    assert fetched is not None
    assert fetched.id == task.id


@pytest.mark.asyncio
async def test_unknown_task_id_returns_none(office):
    assert office.get("not-a-real-id") is None


@pytest.mark.asyncio
async def test_list_tasks_grows_with_each_submission(office):
    await office.submit(title="أولى", brief="")
    await office.submit(title="ثانية", brief="")
    assert len(office.list_tasks()) == 2


@pytest.mark.asyncio
async def test_repeated_qa_rejection_stops_via_max_revisions_not_safety_stop(monkeypatch, office):
    """
    نجبر القبول على الفشل دائمًا بمحاكاة _passes_quality_bar — النظام يتوقف،
    لكن عبر حد MAX_REVISIONS الخاص بالمراجع (أقل بكثير من MAX_STEPS)، وليس
    عبر سقف الأمان العام. هذا يوثّق أيهما يتفعّل أولًا فعليًا.
    """
    qa_agent = office.agents[list(office.agents.keys())[-1]]

    async def always_fail(task):
        return False, "رفض مُحاكى للاختبار", True

    monkeypatch.setattr(qa_agent, "_passes_quality_bar", always_fail)

    task = await office.submit(title="مهمة مستحيلة الإرضاء", brief="")

    assert task.status == TaskStatus.REJECTED
    assert any(e.kind == "rejected_final" for e in task.history)
    assert not any(e.kind == "safety_stop" for e in task.history)


@pytest.mark.asyncio
async def test_safety_stop_triggers_on_genuine_handoff_loop(monkeypatch, office):
    """
    اختبار مباشر لسقف MAX_STEPS نفسه: نحاكي حلقة تسليم بين موظفين لا
    تمر عبر منطق المراجع إطلاقًا (مثلاً خلل مستقبلي بمنطق التوجيه)،
    للتأكد أن office.py نفسه يوقف الحلقة ولا يعتمد فقط على QA.
    """
    from core.task import Role

    developer = office.agents[Role.DEVELOPER]
    designer = office.agents[Role.DESIGNER]

    async def bounce_to_designer(task):
        task.hand_off(Role.DESIGNER, note="loop:dev->designer")

    async def bounce_to_developer(task):
        task.hand_off(Role.DEVELOPER, note="loop:designer->dev")

    monkeypatch.setattr(developer, "handle", bounce_to_designer)
    monkeypatch.setattr(designer, "handle", bounce_to_developer)

    task = await office.submit(title="تصميم شي يسبب حلقة", brief="")

    assert task.status == TaskStatus.REJECTED
    assert any(e.kind == "safety_stop" for e in task.history)
