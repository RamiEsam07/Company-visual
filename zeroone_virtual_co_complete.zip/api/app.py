"""
api/app.py — نقطة الدخول للتطبيق: REST لإدارة المهام، WebSocket لبث الحركة الحية.

تشغيل محلي:
    uvicorn api.app:app --reload --port 8000
"""

from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from core.event_bus import bus
from core.office import office
from core.task import Role

app = FastAPI(title="ZEROONE Virtual Company")

DASHBOARD_DIR = Path(__file__).resolve().parent.parent / "dashboard"


class NewTaskRequest(BaseModel):
    title: str
    brief: str
    created_by: str = "owner"


EMPLOYEES = [
    {"id": "layla", "name": "ليلى أحمد", "role": "manager", "title": "مديرة العمليات", "department": "executive", "zone": "executive", "skills": ["التخطيط", "التنسيق"], "personality": "حازمة ومنظمة"},
    {"id": "omar", "name": "عمر حسن", "role": "developer", "title": "مهندس برمجيات", "department": "engineering", "zone": "engineering", "skills": ["Python", "APIs"], "personality": "تحليلي وهادئ"},
    {"id": "sara", "name": "سارة النور", "role": "designer", "title": "مصممة تجربة", "department": "engineering", "zone": "engineering", "skills": ["UX", "الأنظمة البصرية"], "personality": "فضولية ودقيقة"},
    {"id": "yassin", "name": "ياسين علي", "role": "marketer", "title": "مسؤول نمو", "department": "growth", "zone": "growth", "skills": ["المحتوى", "تحليل السوق"], "personality": "اجتماعي ومبادر"},
    {"id": "noor", "name": "نور محمد", "role": "qa_reviewer", "title": "محللة جودة", "department": "ai", "zone": "ai", "skills": ["الاختبار", "المخاطر"], "personality": "دقيقة ومستقلة"},
]

DEPARTMENTS = [
    {"id": "executive", "name": "الإدارة التنفيذية", "short": "EXEC", "color": "gold", "manager": "ليلى أحمد", "zone": "executive"},
    {"id": "engineering", "name": "هندسة البرمجيات", "short": "ENG", "color": "blue", "manager": "عمر حسن", "zone": "engineering"},
    {"id": "ai", "name": "الذكاء والأنظمة", "short": "AI LAB", "color": "violet", "manager": "نور محمد", "zone": "ai"},
    {"id": "growth", "name": "النمو والعلاقات", "short": "GROWTH", "color": "green", "manager": "ياسين علي", "zone": "growth"},
]


@app.get("/company/state")
async def company_state():
    """قراءة واحدة لحالة الشركة؛ الواجهة لا تعتبر نفسها مصدر الحقيقة."""
    tasks = office.list_tasks()
    task_by_role = {t.assigned_to.value: t for t in tasks if t.assigned_to and t.status.value == "in_progress"}
    employees = []
    for employee in EMPLOYEES:
        task = task_by_role.get(employee["role"])
        employees.append({
            **employee,
            "status": "working" if task else "available",
            "current_task": task.title if task else "مستعد لاستلام مهمة",
            "task_id": task.id if task else None,
            "activity": "تنفيذ مهمة معتمدة" if task else "متاح في القسم",
            "real_execution": bool(task and any(e.payload.get("real_thinking") for e in task.history)),
        })
    active = [t for t in tasks if t.status.value in {"in_progress", "handed_off", "needs_review"}]
    completed = [t for t in tasks if t.status.value == "done"]
    return {
        "company": {"name": "ZEROONE", "legal_name": "ZEROONE for Advanced Digital Solutions", "mode": "local_simulation", "truth_source": "backend"},
        "departments": DEPARTMENTS,
        "employees": employees,
        "metrics": {"employees": len(employees), "active_tasks": len(active), "completed_tasks": len(completed), "attention": sum(1 for t in tasks if t.status.value in {"rejected", "needs_review"})},
        "tasks": [t.to_dict() for t in tasks[-12:]],
    }


@app.post("/tasks")
async def create_task(req: NewTaskRequest):
    task = await office.submit(req.title, req.brief, req.created_by)
    return task.to_dict()


@app.get("/tasks")
async def list_tasks():
    return [t.to_dict() for t in office.list_tasks()]


@app.get("/tasks/{task_id}")
async def get_task(task_id: str):
    task = office.get(task_id)
    if task is None:
        return {"error": "task_not_found"}
    return task.to_dict()


@app.websocket("/ws/live")
async def live_feed(ws: WebSocket):
    await ws.accept()
    queue = bus.subscribe()
    try:
        while True:
            event = await queue.get()
            await ws.send_json(event)
    except WebSocketDisconnect:
        pass
    finally:
        bus.unsubscribe(queue)


# تقديم لوحة المتابعة الثابتة
app.mount("/dashboard", StaticFiles(directory=str(DASHBOARD_DIR)), name="dashboard")


@app.get("/")
async def root():
    return FileResponse(str(DASHBOARD_DIR / "index.html"))


@app.get("/virtual-hq")
async def virtual_hq():
    return FileResponse(str(DASHBOARD_DIR / "3d.html"))
