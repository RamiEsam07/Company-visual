"""
core/event_bus.py — ناقل أحداث بسيط (pub/sub) داخل العملية الواحدة.

كل تغيير يحصل بالشركة الافتراضية (مهمة جديدة، تسليم، موافقة...) يُنشر
هنا، والواجهة (عبر WebSocket) تشترك فيه فتشوف الحركة لحظة بلحظة.
"""

from __future__ import annotations

import asyncio
from typing import Any


class EventBus:
    def __init__(self) -> None:
        self._subscribers: list[asyncio.Queue] = []

    def subscribe(self) -> asyncio.Queue:
        q: asyncio.Queue = asyncio.Queue()
        self._subscribers.append(q)
        return q

    def unsubscribe(self, q: asyncio.Queue) -> None:
        if q in self._subscribers:
            self._subscribers.remove(q)

    async def publish(self, event: dict[str, Any]) -> None:
        for q in list(self._subscribers):
            await q.put(event)


# نسخة واحدة مشتركة لكل التطبيق
bus = EventBus()
