"""
core/thinking.py — طبقة "التفكير" المشتركة بين كل الوكلاء.

كل وكيل يمرر شخصيته (persona) وسياق المهمة، وهذي الطبقة تستدعي Claude
فعليًا وترجع نص القرار/المخرج. لو ما فيه مفتاح API مُعرّف، ترجع خطأ
واضح بدل أي سلوك صامت أو وهمي — حتى ما ندّعي تفكيرًا غير موجود.
"""

from __future__ import annotations

import os

_client = None
_client_init_error: str | None = None


def _get_client():
    """يبني عميل Anthropic مرة واحدة فقط، ويحفظ أي خطأ إعداد بوضوح."""
    global _client, _client_init_error
    if _client is not None or _client_init_error is not None:
        return _client

    if not os.environ.get("ANTHROPIC_API_KEY"):
        _client_init_error = "ANTHROPIC_API_KEY غير معرّف كمتغير بيئة"
        return None

    try:
        import anthropic
        _client = anthropic.Anthropic()
    except Exception as exc:  # pragma: no cover - بيئة بدون المكتبة
        _client_init_error = f"فشل تهيئة مكتبة anthropic: {exc}"
        return None

    return _client


class ThinkingUnavailable(RuntimeError):
    """يُرفع عندما لا يمكن استدعاء نموذج لغوي فعلي — السبب دائمًا صريح."""


async def think(persona: str, task_context: str, model: str = "claude-sonnet-5") -> str:
    """
    يستدعي Claude بشخصية الوكيل (system prompt) وسياق المهمة (user message).
    يرجّع نص القرار/المخرج الخام — كل وكيل يفسّره حسب دوره.

    يرفع ThinkingUnavailable برسالة واضحة لو ما فيه مفتاح API أو فشل
    الاتصال، بدل ما يرجّع نص وهمي يبدو كأنه تفكير فعلي.
    """
    client = _get_client()
    if client is None:
        raise ThinkingUnavailable(_client_init_error or "العميل غير مهيأ لسبب غير معروف")

    try:
        response = client.messages.create(
            model=model,
            max_tokens=600,
            system=persona,
            messages=[{"role": "user", "content": task_context}],
        )
    except Exception as exc:
        raise ThinkingUnavailable(f"فشل استدعاء Claude API: {exc}") from exc

    text_parts = [block.text for block in response.content if block.type == "text"]
    return "\n".join(text_parts).strip()
