"""
core/office.py — "المكتب الافتراضي": يدير دورة حياة المهمة بالكامل،
من لحظة دخولها حتى إغلاقها أو توقفها عند حد الإعادة الأقصى.

هذا هو المكان الوحيد اللي يقرر "مين يشتغل بعد مين" فعليًا بالتنفيذ —
كل وكيل يقرر الوجهة (hand_off)، والمكتب ينفّذها.
"""

from __future__ import annotations

from agents.base_agent import BaseAgent
from agents.developer import DeveloperAgent
from agents.designer import DesignerAgent
from agents.manager import ManagerAgent
from agents.marketer import MarketerAgent
from agents.qa_reviewer import QAReviewerAgent
from core.event_bus import bus
from core.task import Role, Task, TaskStatus

MAX_STEPS = 12  # سقف أمان يمنع أي حلقة تنقل لا نهائية بين الوكلاء


class VirtualOffice:
    def __init__(self) -> None:
        self.agents: dict[Role, BaseAgent] = {
            Role.MANAGER: ManagerAgent(),
            Role.DEVELOPER: DeveloperAgent(),
            Role.DESIGNER: DesignerAgent(),
            Role.MARKETER: MarketerAgent(),
            Role.QA: QAReviewerAgent(),
        }
        self.tasks: dict[str, Task] = {}

    async def submit(self, title: str, brief: str, created_by: str = "owner") -> Task:
        task = Task(title=title, brief=brief, created_by=created_by)
        task.log(actor="system", kind="created", message="مهمة جديدة دخلت المكتب")
        self.tasks[task.id] = task
        await bus.publish({
            "task_id": task.id, "task_title": task.title, "actor": "system", "actor_name": "النظام",
            "kind": "created", "message": f"مهمة جديدة: {task.title}",
        })

        task.assign(Role.MANAGER)
        await self._run_until_settled(task)
        return task

    async def _run_until_settled(self, task: Task) -> None:
        steps = 0
        terminal = {TaskStatus.DONE, TaskStatus.REJECTED}
        while task.status not in terminal and steps < MAX_STEPS:
            if task.assigned_to is None:
                break
            agent = self.agents[task.assigned_to]
            await agent.handle(task)
            steps += 1

        if steps >= MAX_STEPS and task.status not in terminal:
            task.status = TaskStatus.REJECTED
            task.log(
                actor="system", kind="safety_stop",
                message=f"إيقاف أمان بعد {MAX_STEPS} خطوة بدون استقرار — تحتاج مراجعة بشرية",
            )
            await bus.publish({
                "task_id": task.id, "task_title": task.title, "actor": "system", "actor_name": "النظام",
                "kind": "safety_stop", "message": "إيقاف أمان: عدد خطوات غير طبيعي",
            })

    def get(self, task_id: str) -> Task | None:
        return self.tasks.get(task_id)

    def list_tasks(self) -> list[Task]:
        return list(self.tasks.values())


# نسخة واحدة مشتركة للتطبيق كله
office = VirtualOffice()
