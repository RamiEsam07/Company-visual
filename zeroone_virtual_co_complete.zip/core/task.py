"""
core/task.py — نموذج المهمة الأساسي.

كل طلب يدخل الشركة الافتراضية يتحول إلى Task واحد يتنقل بين
الموظفين-الوكلاء، كل وحد يضيف مخرجاته ويمرره للي بعده.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any


class TaskStatus(str, Enum):
    QUEUED = "queued"           # بانتظار موظف يلتقطها
    IN_PROGRESS = "in_progress"  # موظف شغال عليها الآن
    HANDED_OFF = "handed_off"   # سُلّمت لموظف تالي
    NEEDS_REVIEW = "needs_review"  # بانتظار مراجعة الجودة
    REJECTED = "rejected"       # المراجع رفضها، رجعت لصاحبها
    DONE = "done"               # اكتملت ووُفقت عليها


class Role(str, Enum):
    MANAGER = "manager"
    DEVELOPER = "developer"
    DESIGNER = "designer"
    MARKETER = "marketer"
    QA = "qa_reviewer"


@dataclass
class TaskEvent:
    """سجل واحد في تاريخ المهمة — يُستخدم لتغذية الواجهة الحية."""
    at: str
    actor: str
    kind: str          # "created" | "started" | "handoff" | "comment" | "approved" | "rejected" | "completed"
    message: str
    payload: dict[str, Any] = field(default_factory=dict)


@dataclass
class Task:
    title: str
    brief: str
    created_by: str = "owner"
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    status: TaskStatus = TaskStatus.QUEUED
    assigned_to: Role | None = None
    history: list[TaskEvent] = field(default_factory=list)
    artifacts: dict[str, Any] = field(default_factory=dict)  # مخرجات كل موظف باسمه
    revision_count: int = 0

    def log(self, actor: str, kind: str, message: str, **payload: Any) -> TaskEvent:
        event = TaskEvent(
            at=datetime.now(timezone.utc).isoformat(),
            actor=actor,
            kind=kind,
            message=message,
            payload=payload,
        )
        self.history.append(event)
        return event

    def assign(self, role: Role) -> None:
        self.assigned_to = role
        self.status = TaskStatus.IN_PROGRESS

    def hand_off(self, to_role: Role, note: str = "") -> None:
        self.status = TaskStatus.HANDED_OFF
        self.log(
            actor=self.assigned_to.value if self.assigned_to else "system",
            kind="handoff",
            message=note or f"تسليم المهمة إلى {to_role.value}",
            to=to_role.value,
        )
        self.assigned_to = to_role

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "title": self.title,
            "brief": self.brief,
            "status": self.status.value,
            "assigned_to": self.assigned_to.value if self.assigned_to else None,
            "revision_count": self.revision_count,
            "artifacts": self.artifacts,
            "history": [
                {"at": e.at, "actor": e.actor, "kind": e.kind, "message": e.message, "payload": e.payload}
                for e in self.history
            ],
        }
