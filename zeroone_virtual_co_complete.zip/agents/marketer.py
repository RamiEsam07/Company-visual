"""
agents/marketer.py — المسوّق: يعالج الجانب التسويقي/المحتوى، يسلّم للمراجعة.
"""

from __future__ import annotations

from agents.base_agent import BaseAgent
from core.task import Role, Task


class MarketerAgent(BaseAgent):
    role = Role.MARKETER
    display_name = "المسوّق"
    persona = (
        "مسوّق يركّز على الرسالة والجمهور المستهدف قبل الشكل، "
        "يبرر كل اختيار بمحتوى أو نبرة برابطه بهدف الحملة."
    )

    async def handle(self, task: Task) -> None:
        await self._emit(task, "started", "بدأت صياغة الجانب التسويقي")

        result_text, is_real = await self.think(task)
        output = {
            "summary": result_text,
            "status": "draft",
            "real_thinking": is_real,
        }
        task.artifacts[self.role.value] = output
        note = "جهّزت مسودة تسويقية" if is_real else "جهّزت مخرجًا احتياطيًا (تفكير فعلي غير متاح)"
        await self._emit(task, "artifact_ready", note, artifact=output)

        task.hand_off(Role.QA, note="تسليم للمراجعة")
