"""
agents/base_agent.py — الكلاس الأساسي لأي وكيل-موظف في الشركة الافتراضية.

كل دور (مدير، مطور، مصمم...) يرث من هذا الكلاس ويعرّف:
  - persona: شخصيته ونبرة تفكيره
  - handle(): كيف يعالج مهمة يستلمها

التفكير الفعلي هنا placeholder صريح (THINKING_BACKEND) — مصمم ليُستبدل
لاحقًا باستدعاء نموذج لغوي حقيقي بدون تغيير بقية النظام.
"""

from __future__ import annotations

from core.event_bus import bus
from core.task import Role, Task, TaskStatus
from core.thinking import ThinkingUnavailable, think as llm_think


class BaseAgent:
    role: Role
    display_name: str
    persona: str  # وصف شخصيته/أسلوبه — يُستخدم كـ system prompt فعلي عند استدعاء Claude

    def __init__(self) -> None:
        if not hasattr(self, "role"):
            raise NotImplementedError("كل وكيل لازم يحدد role")

    async def _emit(self, task: Task, kind: str, message: str, **payload) -> None:
        task.log(actor=self.role.value, kind=kind, message=message, **payload)
        await bus.publish({
            "task_id": task.id,
            "task_title": task.title,
            "actor": self.role.value,
            "actor_name": self.display_name,
            "kind": kind,
            "message": message,
            **payload,
        })

    def _build_context(self, task: Task) -> str:
        """يبني السياق اللي يُرسل كـ user message — عنوان المهمة ومخرجات من سبقه."""
        lines = [f"عنوان المهمة: {task.title}", f"الوصف: {task.brief}"]
        if task.artifacts:
            lines.append("مخرجات سابقة من زملاء آخرين:")
            for role_name, artifact in task.artifacts.items():
                lines.append(f"- {role_name}: {artifact}")
        lines.append("أنتج مخرجك لهذه المهمة من منظور دورك، بإيجاز ووضوح.")
        return "\n".join(lines)

    async def think(self, task: Task) -> tuple[str, bool]:
        """
        يحاول تفكيرًا فعليًا عبر Claude. لو غير متاح (لا مفتاح API، فشل
        اتصال)، يرجع نصًا احتياطيًا صريحًا — ويُعلن ذلك بوضوح عبر الـ
        boolean الثاني (real=False) بدل التظاهر بأن هذا تفكير فعلي.

        يرجّع: (النص, real) — real=True فقط لو جاء فعليًا من Claude.
        """
        try:
            context = self._build_context(task)
            result = await llm_think(self.persona, context)
            return result, True
        except ThinkingUnavailable as exc:
            fallback = f"[تفكير غير متاح: {exc}] — مخرج احتياطي أولي لـ: {task.title}"
            return fallback, False

    async def handle(self, task: Task) -> None:
        """
        كل دور يبني منطقه الخاص فوق هذي — لازم:
        1) يعلن البداية (_emit kind='started')
        2) يستدعي think() وينتج مخرج
        3) يحفظ المخرج بـ task.artifacts[self.role.value]
        4) يسلّم (task.hand_off) أو يُنهي (task.status = DONE)
        """
        raise NotImplementedError
