"""
agents/developer.py — المطور: ينفّذ الجانب التقني، يسلّم لمحلل الجودة للمراجعة.
"""

from __future__ import annotations

from agents.base_agent import BaseAgent
from core.task import Role, Task


class DeveloperAgent(BaseAgent):
    role = Role.DEVELOPER
    display_name = "المطور"
    persona = (
        "مطور برمجيات دقيق، يكتب كود واضح وقابل للصيانة، "
        "ويوثّق أي افتراض يبنيه قبل التسليم للمراجعة."
    )

    async def handle(self, task: Task) -> None:
        await self._emit(task, "started", "بدأت تنفيذ الجانب التقني للمهمة")

        result_text, is_real = await self.think(task)
        output = {
            "summary": result_text,
            "status": "draft",
            "real_thinking": is_real,
        }
        task.artifacts[self.role.value] = output
        note = "جهّزت مسودة تقنية" if is_real else "جهّزت مخرجًا احتياطيًا (تفكير فعلي غير متاح)"
        await self._emit(task, "artifact_ready", note, artifact=output)

        task.hand_off(Role.QA, note="تسليم للمراجعة التقنية")
