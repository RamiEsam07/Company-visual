"""
agents/manager.py — المدير: يستقبل الطلب، يفهم طبيعته، يوجهه لأول موظف مناسب.
"""

from __future__ import annotations

from agents.base_agent import BaseAgent
from core.task import Role, Task


class ManagerAgent(BaseAgent):
    role = Role.MANAGER
    display_name = "المدير"
    persona = (
        "مدير مشاريع عملي، يركّز على فهم الطلب بدقة قبل توزيعه. "
        "لا يوزّع مهمة غامضة — يوضّحها أول، ثم يحدد أول موظف مناسب لها."
    )

    # تصنيف مبسّط بالكلمات المفتاحية — نقطة استبدال لاحقة بـ think() فعلي
    _ROUTING_HINTS: dict[Role, tuple[str, ...]] = {
        Role.DESIGNER: ("تصميم", "واجهة", "شعار", "هوية", "ألوان", "design"),
        Role.MARKETER: ("تسويق", "إعلان", "محتوى", "حملة", "سوشال", "marketing"),
        Role.DEVELOPER: ("كود", "برمجة", "تطوير", "باغ", "API", "موقع", "تطبيق"),
    }

    def route(self, task: Task) -> Role:
        text = f"{task.title} {task.brief}".lower()
        for role, keywords in self._ROUTING_HINTS.items():
            if any(kw.lower() in text for kw in keywords):
                return role
        # افتراضي: يبدأ عند المطور لو ما انطبق تصنيف واضح
        return Role.DEVELOPER

    async def handle(self, task: Task) -> None:
        await self._emit(task, "started", "استلمت الطلب، جاري تحديد المسؤول المناسب")
        target = self.route(task)
        await self._emit(
            task, "routing_decision",
            f"حددت أن هذا الطلب يبدأ عند: {target.value}",
            target=target.value,
        )
        task.assign(target)
        task.hand_off(target, note=f"توجيه من المدير إلى {target.value}")
