"""
agents/qa_reviewer.py — محلل الجودة: يراجع آخر مخرج قبل إغلاق المهمة.
يملك صلاحية الرفض وإرجاعها لصاحبها — هذي نقطة التحكم الوحيدة بالنظام
التي تمنع إغلاق مهمة ناقصة.
"""

from __future__ import annotations

from core.task import Role, Task, TaskStatus
from core.thinking import ThinkingUnavailable, think as llm_think
from agents.base_agent import BaseAgent

MAX_REVISIONS = 2  # يمنع حلقة رفض/إعادة لا نهائية

_REVIEW_INSTRUCTIONS = (
    "راجع المخرجات أدناه بالنسبة لهذه المهمة. "
    "ابدأ ردك بكلمة واحدة فقط: ACCEPT أو REJECT، "
    "ثم سطر فاصل، ثم سبب قرارك بإيجاز."
)


class QAReviewerAgent(BaseAgent):
    role = Role.QA
    display_name = "محلل الجودة"
    persona = (
        "مراجع صارم لكنه بنّاء — يتحقق أن كل مخرج يطابق ما طلبه العميل فعليًا، "
        "لا يوافق لمجرد وجود مخرج، ويذكر سبب أي رفض بوضوح."
    )

    async def _passes_quality_bar(self, task: Task) -> tuple[bool, str, bool]:
        """
        يرجّع (قبل_أم_لا, السبب, real) — real=False يعني تقييم احتياطي
        (وجود مخرج فقط) لأن التفكير الفعلي غير متاح، مُعلن بصراحة.
        """
        if not task.artifacts:
            return False, "لا يوجد أي مخرج بعد", True  # هذا تقييم منطقي صحيح بدون LLM أصلًا

        try:
            context = self._build_context(task) + "\n\n" + _REVIEW_INSTRUCTIONS
            result = await llm_think(self.persona, context)
            first_line = result.splitlines()[0].strip().upper() if result else ""
            accepted = first_line.startswith("ACCEPT")
            reason = result.split("\n", 1)[1].strip() if "\n" in result else result
            return accepted, reason, True
        except ThinkingUnavailable as exc:
            # fallback صريح: أي مخرج موجود يمر، لكن معلن أنه ليس تقييمًا فعليًا
            return True, f"[تقييم غير فعلي — {exc}] — وُجد مخرج فقط", False

    async def handle(self, task: Task) -> None:
        await self._emit(task, "started", "بدأت مراجعة المخرجات قبل الإغلاق")

        passed, reason, is_real = await self._passes_quality_bar(task)

        if passed:
            task.status = TaskStatus.DONE
            note = reason if is_real else f"المخرجات موجودة — {reason}"
            await self._emit(task, "approved", f"معتمد: {note}", real_review=is_real)
            return

        task.revision_count += 1
        if task.revision_count > MAX_REVISIONS:
            task.status = TaskStatus.REJECTED
            await self._emit(
                task, "rejected_final",
                f"تجاوزت الحد الأقصى لإعادة العمل ({MAX_REVISIONS}) — السبب: {reason}",
                real_review=is_real,
            )
            return

        last_actor = self._last_producing_role(task)
        task.status = TaskStatus.NEEDS_REVIEW
        await self._emit(
            task, "rejected",
            f"مرفوض — {reason} (إعادة لـ {last_actor.value if last_actor else 'غير معروف'})",
            real_review=is_real,
        )
        if last_actor:
            task.hand_off(last_actor, note="إعادة عمل بناءً على ملاحظات المراجعة")

    @staticmethod
    def _last_producing_role(task: Task) -> Role | None:
        for event in reversed(task.history):
            if event.kind == "artifact_ready":
                try:
                    return Role(event.actor)
                except ValueError:
                    continue
        return None
