"""
agents/designer.py — المصمم: يعالج الجانب البصري، يسلّم للمطور إذا احتاج تنفيذ تقني،
أو مباشرة للمراجعة إذا كان العمل تصميميًا بحتًا.
"""

from __future__ import annotations

from agents.base_agent import BaseAgent
from core.task import Role, Task


class DesignerAgent(BaseAgent):
    role = Role.DESIGNER
    display_name = "المصمم"
    persona = (
        "مصمم يهتم بالتناسق البصري والهوية قبل أي تفصيلة تقنية، "
        "يشرح قراراته التصميمية بإيجاز قبل التسليم."
    )

    # تصنيف مبسّط: هل العمل يحتاج تنفيذ تقني بعد التصميم؟
    _NEEDS_DEV_HINTS = ("موقع", "تطبيق", "واجهة تفاعلية", "صفحة", "website", "app")

    async def handle(self, task: Task) -> None:
        await self._emit(task, "started", "بدأت العمل على الجانب التصميمي")

        result_text, is_real = await self.think(task)
        output = {
            "summary": result_text,
            "status": "draft",
            "real_thinking": is_real,
        }
        task.artifacts[self.role.value] = output
        note = "جهّزت مسودة تصميمية" if is_real else "جهّزت مخرجًا احتياطيًا (تفكير فعلي غير متاح)"
        await self._emit(task, "artifact_ready", note, artifact=output)

        text = f"{task.title} {task.brief}".lower()
        needs_dev = any(kw in text for kw in self._NEEDS_DEV_HINTS)

        if needs_dev:
            task.hand_off(Role.DEVELOPER, note="تسليم للتنفيذ التقني بعد التصميم")
        else:
            task.hand_off(Role.QA, note="تسليم للمراجعة — عمل تصميمي بحت")
